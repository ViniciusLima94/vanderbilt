error_msg = {}

error_msg[
    "TimeSamplesException"
] = "Data subset can be specified either in time or in samples, but not both"
error_msg[
    "ChannelIDException"
] = "Listed channel IDs inconsistent with total number of channels)."
